#!/bin/bash

echo "Launching custom extension"
java -jar /opt/aws-lambda-extensions-0.0.1-SNAPSHOT.jar